# Quick Model Testing Without Leaving Current Session

When the user asks "can you try model X?" or wants to validate a model before switching the default, use a one-shot cron job with an explicit model override. This avoids interrupting the current session.

## Pattern

```bash
# 1. Create a one-shot cron job with the target model
cronjob(action='create', name='test-MODEL', model={'model': 'MODEL_NAME'}, prompt='Reply briefly to confirm you are running.', schedule='2026-06-16T00:00:00')

# 2. Trigger it immediately
cronjob(action='run', job_id='<id>')

# 3. Wait ~15-30s, then check output:
ls -laR ~/.hermes/cron/output/<job_id>/
```

The output file (`.md`) contains the model's response under the `## Response` section.

## Why this works

- `cronjob` accepts a `model` override dict that pins the model for that job regardless of the default.
- One-shot (ISO timestamp in the past) jobs auto-delete after execution.
- Output is written to `~/.hermes/cron/output/<job_id>/` even if delivery fails.
- No need to restart gateway or change config.yaml.

## Failure modes

- Invalid model name or unsupported provider → job errors. Check `~/.hermes/cron/logs/<job_id>/`.
- Delivery errors (e.g., Feishu bot not in chat) don't affect the output file.
